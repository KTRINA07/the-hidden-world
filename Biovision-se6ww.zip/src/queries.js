import { HttpError } from 'wasp/server';

export const getUser = async (args, context) => {
  if (!context.user) { throw new HttpError(401); }

  const requestedUser = await context.entities.User.findUnique({
    where: { id: args.id },
    include: {
      chatMessages: {
        include: { toChannel: true }
      }
    }
  });

  if (!requestedUser) { throw new HttpError(404, 'No user found with id ' + args.id); }

  return requestedUser;
};

export const getChannelMessages = async (args, context) => {
  if (!context.user) { throw new HttpError(401); }

  const channelMessages = await context.entities.ChatMessage.findMany({
    where: {
      toChannelId: args.channelId
    },
    include: { sender: true }
  });

  return channelMessages;
};

export const getAllChannels = async (args, context) => {
  if (!context.user) { throw new HttpError(401); }

  return context.entities.Channel.findMany({
    where: {
      isPrivate: false
    }
  });
};
