import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useAction, getUser, getAllChannels, getChannelMessages } from 'wasp/client/operations';

const HomePage = () => {
  const { data: user, isLoading: userLoading, error: userError } = useQuery(getUser);
  const { data: channels, isLoading: channelsLoading, error: channelsError } = useQuery(getAllChannels);
  const { data: channelMessages, isLoading: messagesLoading, error: messagesError } = useQuery(getChannelMessages);

  if (userLoading || channelsLoading || messagesLoading) return 'Loading...';
  if (userError || channelsError || messagesError) return 'Error: ' + (userError || channelsError || messagesError);

  return (
    <div className='p-4'>
      <h1 className='text-3xl font-bold mb-4'>Welcome to BioVision</h1>
      <p className='text-lg mb-2'>BioVision is a mobile chat application designed to connect scientists and students worldwide, fostering collaboration and innovation in biotechnology research.</p>
      <h2 className='text-xl font-semibold mt-6 mb-2'>Owner: Dr. Jane Doe</h2>
      <p className='text-md'>Dr. Jane Doe is a renowned researcher in the field of biotechnology, dedicated to advancing scientific knowledge and breakthroughs.</p>
      <img src='biotech-image.jpg' alt='Biotech Lab' className='w-full h-auto mt-6' />
      {/* Chat List */}
      <div className='mt-8'>
        <h2 className='text-2xl font-bold mb-4'>Chat List</h2>
        <ul className='space-y-4'>
          {channels.map(channel => (
            <li key={channel.id} className='flex items-center justify-between bg-gray-100 p-4 mb-4 rounded-lg'>
              <div>{channel.name}</div>
              <div>{channel.isPrivate ? 'Private' : 'Public'}</div>
              <Link to={`/chat/${channel.id}`} className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'>Join Chat</Link>
            </li>
          ))}
        </ul>
      </div>

      {/* Chat Window */}
      <div className='mt-8'>
        <h2 className='text-2xl font-bold mb-4'>Chat Window</h2>
        <div className='bg-gray-200 p-4 rounded-lg'>
          {/* Display chat messages */}
          {channelMessages.map(message => (
            <div key={message.id} className='mb-2'>
              <strong>{message.sender.username}: </strong> {message.content}
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className='mt-4'>
          <input type='text' placeholder='Type your message...' className='border p-2 w-full' />
          <button className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded mt-2'>Send</button>
        </div>
      </div>
    </div>
  );
}

export default HomePage;