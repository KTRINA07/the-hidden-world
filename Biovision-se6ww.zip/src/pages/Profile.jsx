import React, { useState } from 'react';
import { useQuery, useAction, getUser, updateUser } from 'wasp/client/operations';

const ProfilePage = () => {
  const { data: user, isLoading, error } = useQuery(getUser);
  const updateUserFn = useAction(updateUser);
  const [newUsername, setNewUsername] = useState(user.username);
  const [newEmail, setNewEmail] = useState(user.email);
  const [newBio, setNewBio] = useState(user.bio);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleUpdateUser = () => {
    updateUserFn({
      id: user.id,
      username: newUsername,
      email: newEmail,
      bio: newBio
    });
  };

  return (
    <div className='p-4'>
      <input
        type='text'
        placeholder='Username'
        className='px-1 py-2 border rounded text-lg'
        value={newUsername}
        onChange={(e) => setNewUsername(e.target.value)}
      />
      <input
        type='text'
        placeholder='Email'
        className='px-1 py-2 border rounded text-lg'
        value={newEmail}
        onChange={(e) => setNewEmail(e.target.value)}
      />
      <textarea
        placeholder='Bio'
        className='h-24 px-1 py-2 border rounded text-lg'
        value={newBio}
        onChange={(e) => setNewBio(e.target.value)}
      ></textarea>
      <button
        onClick={handleUpdateUser}
        className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded'
      >
        Update
      </button>
    </div>
  );
}

export default ProfilePage;