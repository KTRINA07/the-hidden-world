import { HttpError } from 'wasp/server'

export const sendMessage = async ({ userId, channelId, messageContent }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const user = await context.entities.User.findUnique({ where: { id: userId } });
  if (!user) { throw new Error('User not found') };

  const channel = await context.entities.Channel.findUnique({ where: { id: channelId } });
  if (!channel) { throw new Error('Channel not found') };

  if (channel.isPrivate && !user.channels.some((c) => c.id === channel.id)) { throw new HttpError(403) };

  return context.entities.ChatMessage.create({
    data: {
      content: messageContent,
      senderId: userId,
      toChannelId: channelId,
      timestamp: Math.floor(Date.now() / 1000)
    }
  });
}

export const createChannel = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) }

  const newChannel = await context.entities.Channel.create({
    data: {
      name: arg.name,
      isPrivate: arg.isPrivate,
      description: arg.description
    }
  });

  return newChannel;
}

export const updateUser = async (arg, context) => {
  if (!context.user) { throw new HttpError(401) };

  const updatedUser = await context.entities.User.update({
    where: { id: arg.userId },
    data: {
      username: arg.username,
      email: arg.email,
      bio: arg.bio,
      interests: arg.interests
    }
  });

  return updatedUser;
}